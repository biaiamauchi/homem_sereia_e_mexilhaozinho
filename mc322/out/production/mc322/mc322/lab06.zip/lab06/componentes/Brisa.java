package mc322.lab06.componentes;

public class Brisa extends Componente{
    public Brisa(String preenchimento){
        super(preenchimento);
    }
}