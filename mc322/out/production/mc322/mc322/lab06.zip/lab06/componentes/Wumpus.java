package mc322.lab06.componentes;

public class Wumpus extends Componente{
    public Wumpus(String preenchimento){
        super(preenchimento);
    }
}
