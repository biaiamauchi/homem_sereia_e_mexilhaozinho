package mc322.lab06.componentes;

public abstract class Componente {
    protected String preenchimento;

    public Componente(String preenchimento){
        this.preenchimento = preenchimento;
    }

    public String getPreenchimento(){
        return preenchimento;
    }

    public void setPreenchimento(String preenchimento){
        this.preenchimento = preenchimento;
    }
}
