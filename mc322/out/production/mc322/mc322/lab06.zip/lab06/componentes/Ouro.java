package mc322.lab06.componentes;

public class Ouro extends Componente{
    public Ouro(String preenchimento){
        super(preenchimento);
    }
}
