package mc322.lab06.componentes;

public class Buraco extends Componente{
    public Buraco(String preenchimento){
        super(preenchimento);
    }
}
