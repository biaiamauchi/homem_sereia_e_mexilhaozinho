package mc322.lab06.componentes;

public class Fedor extends Componente{
    public Fedor(String preenchimento){
        super(preenchimento);
    }
}
