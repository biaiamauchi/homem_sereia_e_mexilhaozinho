package mc322.lab06.componentes;

public class Heroi extends Componente{
    public Heroi(String preenchimento){
        super(preenchimento);
    }
}
